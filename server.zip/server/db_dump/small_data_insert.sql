INSERT INTO team_type(team_type_name, eligible)
VALUES ('Undergrad', true),
    ('Graduate', false),
    ('Alumni', false),
    ('Other', false);
INSERT INTO university(uni_name)
VALUES ('NDSU'),
    ('MSUM'),
    ('UND'),
    ('Other');
